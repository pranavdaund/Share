package tester;

import static util.HibernateUtils.getFactory;

import java.util.Scanner;

import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;

import dao.UserDaoImp;
import pojos.User;

public class LoginCheck {

	public static void main(String[] args) {

		UserDaoImp dao = new UserDaoImp();
		try (SessionFactory sf = getFactory(); Scanner sc = new Scanner(System.in);) {
			System.out.println("hibernate up and running!" + sf);

			System.out.println("Enter email and Password:");

			User user = dao.LoginUser(sc.next(), sc.next());
			if (user != null) {
				System.out.println(user);
				System.out.println("Login SuccessFul");
			} else {
				System.out.println("Login Faild");
			}
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
