package tester;

import static util.HibernateUtils.getFactory;

import java.util.Scanner;

import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;

import dao.UserDaoImp;
import pojos.User;

public class GetChangedPassword {

	public static void main(String[] args) {

		UserDaoImp dao = new UserDaoImp();
		try (SessionFactory sf = getFactory(); Scanner sc = new Scanner(System.in);) {
			System.out.println("hibernate up and running!" + sf);

			System.out.println("Enter Id");
			int id = sc.nextInt();

			System.out.println("Enter Password");
			String newPassword = sc.next();

			User oldinfo = dao.getUserDetails(id);
			System.out.println("user old info " + oldinfo);
			System.out.println(dao.getChangedPassword2(id, newPassword));

		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

//	

}
