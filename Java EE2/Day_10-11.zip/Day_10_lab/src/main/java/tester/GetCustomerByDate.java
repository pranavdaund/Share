package tester;

import static util.HibernateUtils.getFactory;

import java.time.LocalDate;
import java.util.Scanner;

import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;

import dao.UserDaoImp;

public class GetCustomerByDate {

	public static void main(String[] args) {
		UserDaoImp dao = new UserDaoImp();
		try (SessionFactory sf = getFactory(); Scanner sc = new Scanner(System.in);) {
			System.out.println("hibernate up and running!" + sf);

			System.out.println("Enter the Date");
			dao.getCustomersByDate(LocalDate.parse(sc.next())).forEach(System.out::println);

		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
