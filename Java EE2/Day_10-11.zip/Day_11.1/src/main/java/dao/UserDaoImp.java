package dao;

import static util.HibernateUtils.getFactory;

import java.time.LocalDate;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import pojos.Role;
import pojos.User;

public class UserDaoImp implements IUserDao {

	@Override
	public String registerUser(User user) {

		// user: TRANSIENT (not in L1 cache, not in DB)

		// get nibernate session from SF
		Session session = getFactory().openSession();

		// begin tx
		Transaction tx = session.beginTransaction();

		// session object created with empty L1 cache

//		B B 124 124 Admin 9700 2026-06-20
		Session session2 = getFactory().openSession();
		System.out.println(session == session2);
		System.out.println("is open " + session.isOpen() + " connected with db cnn " + session.isConnected());

		try {
			// Method of session i/f : public Serializable save(Object o)
			// o:User Pojo ref

			session.save(user); // user : PERSISTENT => POJO ref added in L1 cache BUT not in db
			tx.commit(); // changes in the object layer will be sync to DB (DML:insert)
			// Hibernate perform auto dirty checking , @ commit

			System.out.println("is open " + session.isOpen() + " connected with db cnn " + session.isConnected());

		} catch (RuntimeException e) {

			// rollback tx
			if (tx != null) {
				tx.rollback();
			}
			throw e; // re throw the same exception to the caller, so that caller(Tester), knows
						// somthing went wrong in the dao layer
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return "User registered with ID " + user.getUserId();

	}

	@Override
	public String registerUserWithGetCurntSession(User user) {

		// user: Detached (not in L1 cache, not in DB)
		// get nibernate session from SF
		Session session = getFactory().getCurrentSession();

		// begin tx
		Transaction tx = session.beginTransaction();

		try {
			// Method of session i/f : public Serializable save(Object o)
			// o:User Pojo ref

			session.update(user); // user : PERSISTENT => POJO ref added in L1 cache BUT not updated in db yet
			tx.commit(); // changes in the object layer will be sync to DB (DML : update)
			// Hibernate perform auto dirty checking , @ commit result in DML : update
			// session is auto closed resulting in L1 cache destroyed, db conn return to the
			// connection pool

		} catch (RuntimeException e) {

			// rollback tx
			if (tx != null) {
				tx.rollback();
			}
			throw e; // re throw the same exception to the caller, so that caller(Tester), knows
						// somthing went wrong in the dao layer
		}
		// user : DETACHED
		return "User registered with ID " + user.getUserId();

	}

	@Override
	public User getUserDetails(int userId) {
		User user = null;
		// get Session from SF : getCurrentSession
		Session session = getFactory().getCurrentSession();

		Transaction tx = session.beginTransaction();

		try {
			// reteive user details : Session API : public <T> T get(Class
			user = session.get(User.class, userId); // int ---> Integer --> Serializable
			// user != null user:PERSISTENT
			tx.commit(); // auto dirty checking --no change, no DMLs, L1 cache destroyed cn return to the
							// pool, session closed

		} catch (Exception e) {

			if (tx != null) {
				tx.rollback();
			}

			throw e;
		}

		return user; // user:DETACHED
	}

	@Override
	public List<User> getAllUserDetails() {

		// get Session from SF : getCurrentSession
		Session session = getFactory().getCurrentSession();
		List<User> users = null;
		String jpql = "Select u from User u";
		Transaction tx = session.beginTransaction();

		try {
			users = session.createQuery(jpql, User.class).getResultList();

			users.forEach(u -> u.setRegAmount(u.getRegAmount() - 50)); // state of PERSISTENT entities is get modified
			tx.commit();
			// hibernate perform auto dirty chking state is dirty => update query is fired
			// to sync state of L1 cache with that of the BD

		} catch (Exception e) {

			if (tx != null) {
				tx.rollback();
			}

			throw e;
		}
		users.forEach(u -> u.setRegAmount(u.getRegAmount() - 50)); // updating the state of DETACHED pojo session, no L1
																	// cache --> does Not propagate changes to DB

		return users;
	}

	@Override
	public List<User> getSelectedUserDetails(LocalDate startDate, LocalDate endDate, Role userRole) {

		// get Session from SF : getCurrentSession
		Session session = getFactory().getCurrentSession();
		List<User> users = null;
		String jpql = "select u from User u where u.regDate between :startDate and :endDate and u.userRole = :userRole";
		Transaction tx = session.beginTransaction();

		try {

			users = session.createQuery(jpql, User.class).setParameter("startDate", startDate)
					.setParameter("endDate", endDate).setParameter("userRole", userRole).getResultList();
			tx.commit();

		} catch (Exception e) {

			if (tx != null) {
				tx.rollback();
			}

			throw e;
		}
		return users;
	}

	@Override
	public User LoginUser(String email, String password) {

		User user = null;

		// get Session from SF : getCurrentSession
		Session session = getFactory().getCurrentSession();
		String jpql = "Select u from User u where u.email = :email and u.password = :password";
		Transaction tx = session.beginTransaction();

		try {
			user = session.createQuery(jpql, User.class).setParameter("email", email).setParameter("password", password)
					.getSingleResult();

			tx.commit();

//			if ((user.getEmail().compareToIgnoreCase(email) == 0) && (user.getPassword().compareTo(password) == 0)) {
//				return "login Successfuly";
//			}

		} catch (Exception e) {

			if (tx != null) {
				tx.rollback();

			}

//			e.printStackTrace();
			throw e;

		}
		return user;
	}

	@Override
	public String getChangedPassword(int userId, String newPassword) {

		// get Session from SF : getCurrentSession
		Session session = getFactory().getCurrentSession();

		String jpql = "UPDATE User u SET u.password = :password WHERE u.userId = :userId";
		Transaction tx = session.beginTransaction();

		try {
			int count = session.createQuery(jpql).setParameter("userId", userId).setParameter("password", newPassword)
					.executeUpdate();

			tx.commit();
			if (count > 0) {
				return "Password updated successfully!";
			} else {
				return "User not found.";
			}

		} catch (Exception e) {

			if (tx != null) {
				tx.rollback();

			}

//			e.printStackTrace();
			throw e;

		}

	}

//	@Override
	public String getChangedPassword2(int userId, String newPassword) {
		Session session = getFactory().getCurrentSession();
		Transaction tx = session.beginTransaction();

		try {
			User user = session.get(User.class, userId);

			if (user == null) {
				return "User not found.";
			}

			user.setPassword(newPassword); // Entity becomes dirty
			tx.commit(); // Hibernate automatically executes UPDATE

			return "Password updated successfully!";
		} catch (Exception e) {
			if (tx != null) {
				tx.rollback();
			}
			throw e;
		}
	}

	@Override
	public List<User> getCustomersByDate(LocalDate regDate) {

		// get Session from SF : getCurrentSession
		Session session = getFactory().getCurrentSession();
		List<User> users;
		String jpql = "select u from User u where u.userRole = 'CUSTOMER' and u.regDate > :regDate order by u.regAmount";
		Transaction tx = session.beginTransaction();

		try {
//regDate
			users = session.createQuery(jpql, User.class).setParameter("regDate", regDate).getResultList();

			tx.commit();

		} catch (Exception e) {

			if (tx != null) {
				tx.rollback();
			}

			throw e;
		}
		return users;
	}

	@Override
	public List<String> getSelectedUsersName(LocalDate startDate, LocalDate endDate, Role userROle) {
		List<String> names;
		// get Session from SF : getCurrentSession
		Session session = getFactory().getCurrentSession();

		Transaction tx = session.beginTransaction();

		String jpql = "Select u.name from User u WHERE u.regDate BETWEEN :startDate AND :endDate and u.userRole = :userRole";

		try {
			names = session.createQuery(jpql, String.class).setParameter("startDate", startDate)
					.setParameter("endDate", endDate).setParameter("userRole", userROle).getResultList();
			tx.commit();

		} catch (Exception e) {

			if (tx != null) {
				tx.rollback();
			}

			throw e;
		}
		return names;
	}

	@Override
	public List<Object[]> getSelectedUserSpecificInfo(LocalDate startDate, LocalDate endDate, Role userROle) {
		List<Object[]> user;
		// get Session from SF : getCurrentSession
		Session session = getFactory().getCurrentSession();

		Transaction tx = session.beginTransaction();

		String jpql = "Select u.name, u.regAmount, u.regDate, u.email from User u WHERE u.regDate BETWEEN :startDate AND :endDate and u.userRole = :userRole";

		try {
			user = session.createQuery(jpql, Object[].class).setParameter("startDate", startDate)
					.setParameter("endDate", endDate).setParameter("userRole", userROle).getResultList();
			tx.commit();

		} catch (Exception e) {

			if (tx != null) {
				tx.rollback();
			}

			throw e;
		}
		return user;
	}

	@Override
	public List<User> getSelectedUserSpecificInfo2(LocalDate startDate, LocalDate endDate, Role userROle) {
		List<User> user;
		// get Session from SF : getCurrentSession
		Session session = getFactory().getCurrentSession();

		Transaction tx = session.beginTransaction();

		String jpql = "Select new pojos.User(name, regAmount, regDate, email) from User u WHERE u.regDate BETWEEN :startDate AND :endDate and u.userRole = :userRole";

		try {
			user = session.createQuery(jpql, User.class).setParameter("startDate", startDate)
					.setParameter("endDate", endDate).setParameter("userRole", userROle).getResultList();
			tx.commit();

		} catch (Exception e) {

			if (tx != null) {
				tx.rollback();
			}

			throw e;
		}
		return user;
	}

}
