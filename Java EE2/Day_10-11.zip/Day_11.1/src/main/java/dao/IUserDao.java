package dao;

import java.time.LocalDate;
import java.util.List;

import pojos.Role;
import pojos.User;

public interface IUserDao {

	// add a moethod to insert details in the db
	String registerUser(User user);

	String registerUserWithGetCurntSession(User user);

	User getUserDetails(int userId);

	List<User> getAllUserDetails();

	// List<User> getUserDetailINBWTDATE(String start, String end);

	List<User> getSelectedUserDetails(LocalDate statDate, LocalDate endDate, Role userRole);

	User LoginUser(String email, String password);

	String getChangedPassword(int userid, String newPassword);

	List<User> getCustomersByDate(LocalDate date);

	List<String> getSelectedUsersName(LocalDate startDate, LocalDate endDate, Role userROle);

	List<Object[]> getSelectedUserSpecificInfo(LocalDate startDate, LocalDate endDate, Role userROle);

	List<User> getSelectedUserSpecificInfo2(LocalDate startDate, LocalDate endDate, Role userROle);

}
