package tester;

import static util.HibernateUtils.getFactory;

import java.time.LocalDate;
import java.util.Scanner;

import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;

import dao.UserDaoImp;
import pojos.Role;
import pojos.User;

public class TestSessionAPI {

	public static void main(String[] args) {
		UserDaoImp dao = new UserDaoImp();
		try (SessionFactory sf = getFactory(); Scanner sc = new Scanner(System.in);) {
			System.out.println("hibernate up and running!" + sf);

			System.out.println(
					"Enter user details: name, email, password, confirmPassword, userRole, regAmount, LocalDate  : ");

			User u = new User(sc.next(), sc.next(), sc.next(), sc.next(), Role.valueOf(sc.next().toUpperCase()),
					sc.nextDouble(), LocalDate.parse(sc.next()));
			System.out.println("User id: " + u.getUserId());
			u.setUserId(5);
			String upadateInfo = dao.registerUserWithGetCurntSession(u);
			System.out.println(upadateInfo);

		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
