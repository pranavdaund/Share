package tester;

import static util.HibernateUtils.getFactory;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;

import dao.UserDaoImp;
import pojos.Role;

public class GetSelectedUserSpecificInfo {

	public static void main(String[] args) {
		UserDaoImp dao = new UserDaoImp();
		try (SessionFactory sf = getFactory(); Scanner sc = new Scanner(System.in);) {

			System.out.println("hibernate up and running!" + sf);

			System.out.println("Enter the StartDate , EndDate, Role: ");

			List<Object[]> list = dao.getSelectedUserSpecificInfo(LocalDate.parse(sc.next()),
					LocalDate.parse(sc.next()), Role.valueOf(sc.next().toUpperCase()));

			list.forEach(lists -> System.out.println(lists[0] + " " + lists[1] + " " + lists[2] + " " + lists[3]));

//			dao.getAllUserDetails().forEach(System.out::println);

//			System.out.println(userinfo);

		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
