package pojos;

import java.time.LocalDate;
import java.util.Arrays;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id; //All JPA Annotations
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
//import javax.management.relation.Role;
@Table(name = "users")
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) // auto increment
	@Column(name = "UserID")
	private Integer userId;

	@Column(name = "Name", length = 20)
	private String name;

	@Column(name = "Email", length = 50, unique = true)
	private String email;

	@Column(name = "Password", length = 20)
	private String password;

	@Transient
	private String confirmPassword;

	@Column(name = "Role", length = 20)
	@Enumerated(EnumType.STRING)
	private Role userRole;

	@Column(name = "Amount")
	private double regAmount;

	@Column(name = "Date")
	private LocalDate regDate;

	@Column(name = "ImageURL")
	@Lob
	private byte[] image;

	public User() {
		// TODO Auto-generated constructor stub
		System.out.println("in user ctor");
	}

	public User(String name, String email, String password, String confirmPassword, Role userRole, double regAmount,
			LocalDate regDate) {
		super();
		this.name = name;
		this.email = email;
		this.password = password;
		this.confirmPassword = confirmPassword;
		this.userRole = userRole;
		this.regAmount = regAmount;
		this.regDate = regDate;
	}

	public User(String name, double regAmount, LocalDate regDate, String email) {
		super();
		this.name = name;
		this.regAmount = regAmount;
		this.regDate = regDate;
		this.email = email;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Role getUserRole() {
		return userRole;
	}

	public void setUserRole(Role userRole) {
		this.userRole = userRole;
	}

	public double getRegAmount() {
		return regAmount;
	}

	public void setRegAmount(double regAmount) {
		this.regAmount = regAmount;
	}

	public LocalDate getRegDate() {
		return regDate;
	}

	public void setRegDate(LocalDate regDate) {
		this.regDate = regDate;
	}

	public byte[] getImage() {
		return image;
	}

	public void setImage(byte[] image) {
		this.image = image;
	}

	public String getConfirmPassword() {
		return confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", name=" + name + ", email=" + email + ", password=" + password
				+ ", confirmPassword=" + confirmPassword + ", userRole=" + userRole + ", regAmount=" + regAmount
				+ ", regDate=" + regDate + ", image=" + Arrays.toString(image) + "]";
	}

}
