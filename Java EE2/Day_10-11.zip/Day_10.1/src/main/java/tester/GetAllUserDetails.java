package tester;

import static util.HibernateUtils.getFactory;

import java.util.Scanner;

import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;

import dao.UserDaoImp;

public class GetAllUserDetails {

	public static void main(String[] args) {
		UserDaoImp dao = new UserDaoImp();
		try (SessionFactory sf = getFactory(); Scanner sc = new Scanner(System.in);) {

			System.out.println("hibernate up and running!" + sf);

			dao.getAllUserDetails().forEach(System.out::println);

//			System.out.println(userinfo);

		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
