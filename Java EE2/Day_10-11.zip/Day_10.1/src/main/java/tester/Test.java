package tester;

import static util.HibernateUtils.getFactory;

import java.time.LocalDate;
import java.util.Scanner;

import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;

import dao.UserDaoImp;

//import javax.management.relation.Role;

import pojos.Role;
import pojos.User;

public class Test {

	public static void main(String[] args) {

		try (SessionFactory sf = getFactory(); Scanner sc = new Scanner(System.in);) {
			System.out.println("hibernate up and running!" + sf);

			System.out.println(
					"Enter user details: name, email, password, confirmPassword, userRole, regAmount, LocalDate, regDate(yy-mm-dd): ");

			UserDaoImp dao = new UserDaoImp();
			String upadateInfo = dao.registerUser(new User(sc.next(), sc.next(), sc.next(), sc.next(),
					Role.valueOf(sc.next().toUpperCase()), sc.nextDouble(), LocalDate.parse(sc.next())));
			System.out.println(upadateInfo);

		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
