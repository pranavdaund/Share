package tester;

import static util.HibernateUtils.getFactory;

import java.util.Scanner;

import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;

import dao.UserDaoImp;
import pojos.User;

public class TestWithGetCurrentSession {

	public static void main(String[] args) {
		UserDaoImp dao = new UserDaoImp();
		try (SessionFactory sf = getFactory(); Scanner sc = new Scanner(System.in);) {
			System.out.println("hibernate up and running!" + sf);

//			System.out.println(
//					"Enter user details: name, email, password, confirmPassword, userRole, regAmount, LocalDate, regDate(yy-mm-dd): ");
//
//			
//			String upadateInfo = dao.registerUserWithGetCurntSession(new User(sc.next(), sc.next(), sc.next(),
//					sc.next(), Role.valueOf(sc.next().toUpperCase()), sc.nextDouble(), LocalDate.parse(sc.next())));

			System.out.println("Enter the id");
			User userinfo = dao.getUserDetails(sc.nextInt());

			System.out.println(userinfo);

		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
