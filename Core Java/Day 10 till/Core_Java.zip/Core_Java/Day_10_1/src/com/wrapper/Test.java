package com.wrapper;

public class Test {
	public static void main(String[] args) {
		Integer ref = new Integer(1234);
		System.out.println(ref);
		int data = ref;
		System.out.println(data);
		System.out.println(ref.intValue());
	}

}
