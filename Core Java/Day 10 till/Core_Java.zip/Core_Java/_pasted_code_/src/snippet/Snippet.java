package snippet;

public class Snippet {
	public static void main(String[] args) {
		day1_q7.html
	}
}

