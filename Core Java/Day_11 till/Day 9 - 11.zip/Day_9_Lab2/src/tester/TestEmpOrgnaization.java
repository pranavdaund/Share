package tester;

import static utils.ValidationRules.validateAllInputs;

import java.util.Scanner;

import com.app.core.Employee;

import customException.EmpHandlingException;

public class TestEmpOrgnaization {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter the maxinum number of emp");
			Employee emp[] = new Employee[sc.nextInt()];
			boolean exit = false;
			int counter = 0;
			while (!exit) {
				System.out.println("1.Hired Emp \n2.Display All \n3.Exit");
				System.out.println("Enter the Choice");
				try {
					switch (sc.nextInt()) {
					case 1:
						if (counter < emp.length) {
							System.out.println(
									"Enter emp deatils - empid, firstName, LastName, email, deptId, joinDate, Salary");

							Employee e = validateAllInputs(sc.nextInt(), emp, sc.next(), sc.next(), sc.next(),
									sc.next(), sc.next(), sc.nextDouble());
//							emp[counter++] = new Employee(validateEmpId(sc.nextInt(), emp),
//									validateName(sc.next(), "First"), validateName(sc.next(), "Last"),
//									validEmail(sc.next()), validateDept(sc.next()), parseValidateJoinDate(sc.next()),
//									sc.nextDouble());
							emp[counter++] = e;
							System.out.println("Employee Hired ");

						} else {
							throw new EmpHandlingException("Recurement Over");
						}
						break;
					case 2:
						for (Employee e : emp) {
							if (e != null) {
								System.out.println(e);
							}
						}
						break;

					case 3:
						exit = true;
						break;

					}// swith over
				} // inner try over
				catch (Exception e) {
					// TODO: handle exception
					System.out.println("Error" + e);

				}
				// clear off all pending input from scanner buufer till next line
				sc.nextLine();
			} // end of while
		} // try with resources over
	}// main end

}
