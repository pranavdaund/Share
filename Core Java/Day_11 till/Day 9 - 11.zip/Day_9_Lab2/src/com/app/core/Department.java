package com.app.core;

public enum Department {

}
