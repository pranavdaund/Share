package com.app.core;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Employee {
	private int empid;
	private String firstName;
	private String lasName;
	private String email;
	private String deptId;
	private Date joinDate;
	private double salary;

	public Employee(int empid) {
		// TODO Auto-generated constructor stub
		this.empid = empid;
	}

	// add sdf for parsing (String --> Date) and format (Date-->String)
	public static SimpleDateFormat sdf;

	// static initi for initing sdf:day/mon/yr -- pattern
	static {
		sdf = new SimpleDateFormat("dd/MM/yyyy");
	}

	public Employee(int empid, String firstName, String lasName, String email, String deptId, Date date,
			double salary) {
		super();
		this.empid = empid;
		this.firstName = firstName;
		this.lasName = lasName;
		this.email = email;
		this.deptId = deptId;
		this.joinDate = date;
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Employee empid=" + empid + ", firstName=" + firstName + ", lasName=" + lasName + ", email=" + email
				+ ", deptId=" + deptId + ", date=" + sdf.format(joinDate) + ", salary=" + salary;
	}

	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		System.out.println("in emp equals");
		if (obj instanceof Employee) {
			Employee e = (Employee) obj;
			return this.empid == e.empid;
		}
		return false;
	}

}
