package com.enums;

public class Tester {
	enum Direction {
		EAST(0), WEST(180), NORTH(90), SOUTH(270);

		private int angle;
		private Direction(final int angle) {
			this.angle = angle;
		}

		public int getAngle() {
			return angle;
		}

	}

	public static void main(String[] args) {
		System.out.println(Direction.WEST.angle);
	}

}
