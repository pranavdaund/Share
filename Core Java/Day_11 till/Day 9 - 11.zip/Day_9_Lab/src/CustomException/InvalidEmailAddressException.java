package CustomException;

public class InvalidEmailAddressException extends Exception {
	public InvalidEmailAddressException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
}
