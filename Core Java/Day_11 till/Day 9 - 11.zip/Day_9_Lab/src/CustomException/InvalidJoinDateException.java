package CustomException;

public class InvalidJoinDateException extends Exception {

	public InvalidJoinDateException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
}
