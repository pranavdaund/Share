package CustomException;

public class EmployeeNameException extends Exception {

	public EmployeeNameException(String msg) {
		// TODO Auto-generated constructor
		super(msg);
	}
}
