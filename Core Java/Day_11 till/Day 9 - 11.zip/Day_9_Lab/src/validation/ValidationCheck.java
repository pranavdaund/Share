package validation;

import java.text.SimpleDateFormat;
import java.util.Date;

import CustomException.EmployeeNameException;
import CustomException.InvalidJoinDateException;

public class ValidationCheck {

	public static SimpleDateFormat sdf;
	public static Date lastDate;

	public static final int MIN_LENGTH;
	public static final int MAX_LENGTH;

	static {
		sdf = new SimpleDateFormat("dd/MM/yyyy");
		MIN_LENGTH = 4;
		MAX_LENGTH = 15;
		try {
			lastDate = sdf.parse("01/04/2021");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

	}

	public static String nameValidation(String name) {
		try {
			if (name.length() < MIN_LENGTH) {
				throw new EmployeeNameException("Name Character is less than 4");
			}
			if (name.length() > MAX_LENGTH) {
				throw new EmployeeNameException("Name Character is greater than 15");
			}
			// System.out.println("Name length is Correct");
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
		return name;
	}

	public static Date joinDateValidation(Date joinDate) {

		try {
			if (joinDate.before(lastDate)) {
				throw new InvalidJoinDateException("Join Date before " + sdf.format(joinDate));
			}
			// System.out.println("Join Date is Coorect");

		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}

		return joinDate;

	}

	public static String emailAddressValidation(String email) {

		try {
			if (email.contains("@") && email.endsWith(".com")) {
				return email;
			} else {
				throw new EmployeeNameException("email address is invalid");
			}

		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
		return "";
	}

}
