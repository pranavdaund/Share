package tester;

import java.util.Scanner;

import com.app.core.Employee;

public class Test {
	public static void main(String[] args) {

		try (Scanner sc = new Scanner(System.in)) {
			int count = 0;
			System.out.println("Enter the size of array");
			Employee e[] = new Employee[sc.nextInt()];
			boolean exit = false;
			while (exit) {
				System.out.println("1.Hired Date \n2.Display all \n3.Exit");
				switch (sc.nextInt()) {
				case 1:

					break;

				default:
					break;
				}
			}
		}

	}

}
