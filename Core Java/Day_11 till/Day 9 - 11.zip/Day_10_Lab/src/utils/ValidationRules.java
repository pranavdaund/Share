package utils;

import static com.app.core.Department.valueOf;
import static com.app.core.Employee.sdf;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.app.core.Department;
import com.app.core.Employee;

import customException.EmpHandlingException;

public class ValidationRules {

	public static Date threSholdDate;
	public static Date lastDate;
	public static final int MIN_LENGTH;
	public static final int MAX_LENGTH;

	static {
		sdf = new SimpleDateFormat("dd/MM/yyyy");
		MIN_LENGTH = 4;
		MAX_LENGTH = 15;
		try {
			threSholdDate = sdf.parse("01/04/2021");
			lastDate = sdf.parse("01/04/2021");
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Error in Static block" + e);
		}

	}

	public static Employee validateAllInputs(int empid, Employee[] empData, String firstName, String lastName,
			String emial, String deptId, String joinDate, Double salary) throws EmpHandlingException, ParseException {
		validateEmpId(empid, empData);
		validateName(firstName, "First");
		validateName(lastName, "Last");
		validEmail(emial);
		Department dept = validateDept(deptId);
		Date date = parseValidateJoinDate(joinDate);

		return new Employee(empid, firstName, lastName, emial, dept, date, salary);

	}

	public static String validEmail(String email) throws EmpHandlingException {
		if (email.contains("@") && email.endsWith(".com")) {
			return email;
		}
		throw new EmpHandlingException("Invalid Email");
	}

	public static String validateName(String name, String mesg) throws EmpHandlingException {
		if (name.length() < MIN_LENGTH || name.length() > MAX_LENGTH) {
			throw new EmpHandlingException("Invalid " + mesg + " Name: must be within a range 4 -15");
		}
		return name;
	}

	public static Date validDate(Date joinDate) throws EmpHandlingException {

		if (joinDate.before(lastDate)) {
			throw new EmpHandlingException("Join Date before " + sdf.format(joinDate));
		}

		return joinDate;

	}

//	public static Department validateDept(String dept) throws EmpHandlingException {
//		switch (dept.toUpperCase()) {
//		case "RND":
//		case "FINANCE":
//		case "MARKETING":
//		case "HR":
//		case "PRODUCTION":
//
//			return dept;
//		default:
//			throw new EmpHandlingException("Invalid Department");
//
//		}
//
//	}

	public static Department validateDept(String dept) {
		return valueOf(dept.toUpperCase());
	}

	public static Date parseValidateJoinDate(String joinDate) throws ParseException, EmpHandlingException {
		Date d1 = sdf.parse(joinDate);

		if (d1.after(threSholdDate)) {
			return d1;
		}
		throw new EmpHandlingException("Invalid Join Date");
	}

	public static int validateEmpId(int empId, Employee[] empDate) throws EmpHandlingException {
		Employee emp = new Employee(empId);

		for (Employee e : empDate) {
			if (e != null) {
				if (e.equals(emp)) {
					throw new EmpHandlingException("Already Exit Emp ID");
				}
			}
		}
		return empId;
	}

	public static Employee getEmpDetails(int empId, Employee[] empDate) throws EmpHandlingException {
		Employee emp = new Employee(empId);

		for (Employee e : empDate) {
			if (e != null) {
				if (e.equals(emp)) {
					return e;
				}
			}
		}
		throw new EmpHandlingException("Emp not found");

	}

}
