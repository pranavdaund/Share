package customException;

public class EmpHandlingException extends Exception {

	public EmpHandlingException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}

}
