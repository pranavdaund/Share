package com.app.core;

public enum Department {
	RND, FINANCE, MARKETING, HR, PRODUCTION;

}
