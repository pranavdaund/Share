package org.pranav;

public class Test5 {
	public static void main(String[] args) {
		StringBuilder sb1 = new StringBuilder();
		System.out.println(sb1.length() + " " + sb1.capacity());
		StringBuilder sb2 = new StringBuilder();
		sb2.append(
				"qwertyuiopwsedrtyuiopqwertyuiopqwertyuiop[asdfghjklzxcvbnmzxcvbnmasdfghjklqwertyuiopqwertyuiopasdfghjklzxcvbnm");
		System.out.println(sb2.length() + " " + sb2.capacity());

		StringBuilder sb3 = new StringBuilder("hello");
		System.out.println(sb3.length() + " " + sb3.capacity());
		sb3.append(true);
		sb3.append(1234.256);
		StringBuilder sb4 = sb3.append(345683456766l);
		System.out.println(sb3);
		System.out.println(sb4);
		System.out.println(sb3 == sb4);
		System.out.println(sb3.length() + " " + sb3.capacity());
		sb3.insert(2, 9999);
		System.out.println(sb4);
		sb4.delete(1, 4);
		System.out.println(sb3);
		sb3.reverse();
		System.out.println(sb3);
		System.out.println(sb4);

		System.out.println();
		System.out.println("New Code");

		StringBuilder s1 = new StringBuilder("hello");
		StringBuilder s2 = new StringBuilder("hello");

		System.out.println(s1 == s2);
		System.out.println(s1.equals(s2));

	}

}
