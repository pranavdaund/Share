package org.pranav;

public class TestString1 {
	public static void main(String[] args) {
		String s1 = new String("hello");
		s1.concat("hi!");
		String s2 = s1.concat("hi!");
		System.out.println(s1);
		System.out.println(s2);
		s1 += "1234";
		System.out.println(s1);
		System.out.println(s1.toUpperCase());
		System.out.println(s2);

		String s3 = s2.replace('l', 't');
		System.out.println(s2);
		System.out.println(s3);
	}

}
