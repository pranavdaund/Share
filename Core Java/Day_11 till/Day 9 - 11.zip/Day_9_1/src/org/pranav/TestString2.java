package org.pranav;

public class TestString2 {
	public static void main(String[] args) {
		String s1 = new String("testing123");
		String s2 = new String("testing123");
		System.out.println(s1 == s2);
		System.out.println(s1.equals(s2));
		String s3 = new String("TESTING123");
		System.out.println(s1 == s2);
		System.out.println(s1.equals(s3));
		System.out.println(s1.equalsIgnoreCase(s3));
	}

}
