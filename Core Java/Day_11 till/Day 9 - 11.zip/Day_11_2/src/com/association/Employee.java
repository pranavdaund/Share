package com.association;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Employee {

	class AadharCard {
		private long cardNumber;
		private Date creationCard;
		private String location;

		public AadharCard(long cardNumber, Date creationCard, String location) {
			super();
			this.cardNumber = cardNumber;
			this.creationCard = creationCard;
			this.location = location;
		}

		public long getCardNumber() {
			return cardNumber;
		}

		public Date getCreationCard() {
			return creationCard;
		}

		public String getLocation() {
			return location;
		}

	}

	private int id;
	private String name;
	private double salary;
	private AadharCard card;

	public Employee() {
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public Employee(int id, String name, double salary) {
//		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
	}

	public void isAadharCard() {
		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter Card Number");
			long cardNumber = sc.nextLong();

			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			System.out.println("Enter AadharCard Date (DD/MM/YYYY)");
			Date date = sdf.parse(sc.next());

			System.out.println("Enter the Location");
			String location = sc.next();
			
			AadharCard newCard = new AadharCard(cardNumber, date, location);
			this.card = newCard;

		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return id + " " + name + " " + salary + " " + card.cardNumber + " " + card.creationCard + " " + card.location;
	}


}
