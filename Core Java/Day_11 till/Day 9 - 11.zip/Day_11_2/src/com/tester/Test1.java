package com.tester;

import com.association.Employee;

public class Test1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee e1 = new Employee();
		e1.isAadharCard();
		System.out.println(e1);

	}

}
