package nested_class;

public class A {

}
