package com.tester;

import java.text.SimpleDateFormat;
import java.util.Date;
//import java.util.Date;
import java.util.Scanner;

public class Test1 {

	public static void main(String[] args) {
		try (Scanner sc = new Scanner(System.in)) {
			SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
			System.out.println("Enter join Date of the 1st Emp(dd/mm/yyyy)");
			Date joinDate1 = sdf.parse(sc.next());
			System.out.println("Enter join Date of the 2st Emp(dd/mm/yyyy)");
			Date joinDate2 = sdf.parse(sc.next());
			if (joinDate1.before(joinDate2)) {
				System.out.println("Emp1 is Senior");
			} else {
				System.out.println("Emp2 is Senior");
			}
			System.out.println("to String of Date " + joinDate1);
			System.out.println("formatted Data String " + sdf.format(joinDate1));
			
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
		System.out.println("Main Continue.....");
	}

}

/*
 * Enter join Date of the 1st Emp(dd/mm/yyyy) 21/06/2019 Enter join Date of the
 * 2st Emp(dd/mm/yyyy) 21/09/2025 Emp1 is Senior to String of DateMon Jan 21
 * 00:06:00 IST 2019 formatted Data String21/06/2019 Main Continue.....
 * 
 */
