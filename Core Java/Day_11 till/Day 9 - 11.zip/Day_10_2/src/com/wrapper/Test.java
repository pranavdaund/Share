package com.wrapper;

public class Test {
	@SuppressWarnings("removal")
	public static void main(String[] args) {
		int num1 = 465;

	}

}
