package com.enums;

import static com.enums.Department.valueOf;
import static com.enums.Department.values;

import java.util.Arrays;
import java.util.Scanner;

public class Test {
	public static void main(String[] args) {
		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("Valid Department to choose :" + Arrays.toString(values()));
			System.out.println("Enter dept name");
			Department selectDepartment = valueOf(sc.next().toUpperCase());
			System.out.println("You chose: " + selectDepartment);
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
		System.out.println("Main is continue");
	}

}
