package com.enums;

public enum Department {
	RND, FINANCE, MARKETING, HR, PRODUCTION;

	@Override
	public String toString() {
		return name().toLowerCase();
	}

}
