package com.app.core;

import static com.app.core.Employee.sdf;

import java.util.Date;

public class AdharCard {
	private String cardNumber;
	private Date createDate;
	private String location;

	public AdharCard(String cardNumber, Date createDate, String location) {
		super();
		this.cardNumber = cardNumber;
		this.createDate = createDate;
		this.location = location;
	}

	@Override
	public String toString() {
		return "AdharCard [cardNumber=" + cardNumber + ", createDate=" + sdf.format(createDate) + ", location="
				+ location + "]";
	}

	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		if (obj instanceof AdharCard) {
			AdharCard a = (AdharCard) obj;
			return this.cardNumber.equals(a.cardNumber);
		}
		return false;
	}

}
