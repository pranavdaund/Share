package com.app.core;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Employee {
	private int empid;
	private String firstName;
	private String lasName;
	private String email;
	private Department deptId;
	private Date joinDate;
	private double salary;

	// add additional state : to establish HSA - A ,EMP HSA-A AdharCard
	private AdharCard card;

	public Employee(int empid) {
		// TODO Auto-generated constructor stub
		this.empid = empid;
	}

	// add sdf for parsing (String --> Date) and format (Date-->String)
	public static SimpleDateFormat sdf;

	// static initi for initing sdf:day/mon/yr -- pattern
	static {
		sdf = new SimpleDateFormat("dd/MM/yyyy");
	}

	public Employee(int empid, String firstName, String lasName, String email, Department deptId, Date date,
			double salary) {
		super();
		this.empid = empid;
		this.firstName = firstName;
		this.lasName = lasName;
		this.email = email;
		this.deptId = deptId;
		this.joinDate = date;
		this.salary = salary;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public Department getDeptId() {
		return deptId;
	}

	public void setDeptId(Department deptId) {
		this.deptId = deptId;
	}

	@Override
	public String toString() {
		String mesg = card == null ? "Aadhar Card not yet linked!!!" : card.toString();
		return "Employee empid=" + empid + ", firstName=" + firstName + ", lasName=" + lasName + ", email=" + email
				+ ", deptId=" + deptId + ", date=" + sdf.format(joinDate) + ", salary=" + salary + " " + mesg;
	}

	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		System.out.println("in emp equals");
		if (obj instanceof Employee) {
			Employee e = (Employee) obj;
			return this.empid == e.empid;
		}
		return false;
	}

	// add a method to link adhar card to the current emp
	public void linkAdharCard(String cardNumber, Date createDate, String location) {
		this.card = new AdharCard(cardNumber, createDate, location);
	}

}
