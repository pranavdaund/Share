package tester;

import java.util.Date;

import com.app.core.AdharCard;

public class TestAssociation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AdharCard card = new AdharCard("asdfghj", new Date(), "Mumbai");

	}

}
