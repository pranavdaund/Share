package p2;

//Different Package non sub class
import p1.A;

public class E {
	public E() {
		// TODO Auto-generated constructor stub
		A a = new A();
//		System.out.println("Class E private " + a.i); // java c error
//		System.out.println("Class E default " + a.j); // java c error
//		System.out.println("Class E protected " + a.k); // java c error
		System.out.println("Class E public " + a.l);
	}

}
