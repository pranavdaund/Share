package p2;

//Different Package Sub class
import p1.A;

public class D extends A {

	public D() {
		// TODO Auto-generated constructor stub
//		System.out.println("Class D private " + i);
//		System.out.println("Class D default " + j);
		System.out.println("Class D protected " + k);
		System.out.println("Class D public " + l);
	}

}
