package p1;

// same package sub class
public class B extends A {

	public B() {
		// TODO Auto-generated constructor stub
//		System.out.println("Class B private " + i);
		System.out.println("Class B default " + j);
		System.out.println("Class B protected " + k);
		System.out.println("Class B public " + l);
	}
}
