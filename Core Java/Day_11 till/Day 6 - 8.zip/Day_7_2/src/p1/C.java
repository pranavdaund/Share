package p1;

// same package non sub class
public class C {

	public C() {
		A a = new A();

//		System.out.println("Class C default " + a.i);
		System.out.println("Class C default " + a.j);
		System.out.println("Class C protected " + a.k);
		System.out.println("Class C public " + a.l);
	}

}
