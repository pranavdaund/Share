package p1;

//same class
public class A {
	private int i = 10;
	int j = 20;
	protected int k = 30;
	public int l = 40;

	public A() {
		// TODO Auto-generated constructor stub
		System.out.println("Class A private " + i);
		System.out.println("Class A default " + j);
		System.out.println("Class A protected " + k);
		System.out.println("Class A public " + l);
	}

}
