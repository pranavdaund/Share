package tester;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a = 100;
		int b = 10;
		try {
			System.out.println("Result is" + (a / b)); // java.lang.ArithmeticException
			System.out.println("End of try...!");
		} catch (ArithmeticException e) {
			// TODO: handle exception
			System.out.println("Exception occurred...!");
		}

		System.out.println("Main over...!");

	}

}
