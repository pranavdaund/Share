package com.store.vehicle;

public class Vehicle {

	private int speed;

	static final int minSpeed = 30;
	static final int maxSpeed = 80;

	public Vehicle(int speed) throws SpeedOutofRangedException {
		// TODO Auto-generated constructor stub
		checkSpeed(speed);
	}

	public void checkSpeed(int speed) throws SpeedOutofRangedException {
		if (speed <= minSpeed || speed >= maxSpeed) {
			throw new SpeedOutofRangedException("Out of spped");
		} else {
			this.speed = speed;
		}
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "speed is: " + speed;
	}

}
