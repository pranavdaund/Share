package com.store.vehicle;

public class SpeedOutofRangedException extends Exception {

	public SpeedOutofRangedException(String e) {
		// TODO Auto-generated constructor stub
		super(e);
	}

}
