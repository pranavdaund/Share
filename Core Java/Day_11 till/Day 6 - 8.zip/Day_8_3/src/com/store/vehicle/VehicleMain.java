package com.store.vehicle;

public class VehicleMain {

	public static void main(String[] args) {
		Vehicle v1;
		try {
			v1 = new Vehicle(40);
			System.out.println(v1);
			v1 = new Vehicle(90);
			System.out.println(v1);
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
	}

}
