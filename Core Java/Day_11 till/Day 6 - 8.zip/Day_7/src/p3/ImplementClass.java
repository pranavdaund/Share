package p3;

public abstract class ImplementClass implements A, B {

	@Override
	public void show() { // TODO Auto-generated method stub
		System.out.println("non parameter show function");

	}
}
