package p1;

public interface Computable {

	double Computable(double a, double b);

}
