package p1;

public class ImplementClass implements Printable, Computable {

	@Override
	public void print(String msg) {
		System.out.println("Print a mesg " + msg);

	}

	@Override
	public double Computable(double a, double b) {
		// TODO Auto-generated method stub
		return a + b;
	}

}
