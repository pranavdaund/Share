package p2;

public class Mian {
	public static void main(String[] args) {
		ImplementClass obj = new ImplementClass();
		obj.show();
		obj.show("Welcome");
	}

}
