package p2;

public class ImplementClass implements A, B {

	@Override
	public void show() {
		// TODO Auto-generated method stub
		System.out.println("non parameter show function ");

	}

	@Override
	public void show(String msg) {
		// TODO Auto-generated method stub
		System.out.println("parameter show Function  " + msg);

	}

}
