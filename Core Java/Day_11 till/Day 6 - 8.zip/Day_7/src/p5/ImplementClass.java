package p5;

public class ImplementClass implements C {

	@Override
	public void show() {
		// TODO Auto-generated method stub
		System.out.println("in show method");

	}

	@Override
	public String convert(int num) {
		// TODO Auto-generated method stub

		return num + "";
	}

	@Override
	public boolean isEven(int num) {
		// TODO Auto-generated method stub
		if (num % 2 == 0) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public void print(String msg) {
		// TODO Auto-generated method stub

	}

}
