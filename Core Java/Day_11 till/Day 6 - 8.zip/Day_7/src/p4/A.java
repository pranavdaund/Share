package p4;

public interface A {
	double DATA = 100.0;

	void show();

}
