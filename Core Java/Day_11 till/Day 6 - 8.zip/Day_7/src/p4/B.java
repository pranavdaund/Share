package p4;

public interface B {
	double DATA = 200.0;

	void show();
}
