package p4;

public class Main {

	public static void main(String[] args) {
		ImplementClass obj = new ImplementClass();
		obj.show();
	}

}
