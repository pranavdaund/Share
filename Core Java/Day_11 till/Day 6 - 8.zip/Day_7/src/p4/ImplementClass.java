package p4;

public class ImplementClass implements A, B {

	@Override
	public void show() { // TODO Auto-generated method stub
		System.out.println(" in show " + A.DATA + " " + B.DATA);

	}
}
