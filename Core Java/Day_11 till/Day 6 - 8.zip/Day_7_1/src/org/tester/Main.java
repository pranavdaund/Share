package org.tester;

import org.app.shapes.BoundedShape;
import org.app.shapes.Circle;
import org.app.shapes.Rectangle;

public class Main {

	public static void main(String[] args) {
		BoundedShape shapes[] = { new Circle(10, 20, 7.9), new Rectangle(11, 22, 12.5, 15.5) };

		for (BoundedShape shape : shapes) {
			System.out.println(shape);
			System.out.println("Area: " + shape.calArea() + ", Perimeter: " + shape.calPerimeter());
		}
	}

}
