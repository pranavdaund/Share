package org.app.shapes;

public interface AreaCompuation {
	double PI = Math.PI;

	double calArea();

}
