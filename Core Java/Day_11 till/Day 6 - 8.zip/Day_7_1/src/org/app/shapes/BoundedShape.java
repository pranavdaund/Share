package org.app.shapes;

public abstract class BoundedShape implements AreaCompuation, PerimeterComputation {

	private int x, y;

	public BoundedShape(int x, int y) {
		// TODO Auto-generated constructor stub
		this.x = x;
		this.y = y;

	}

	@Override
	public String toString() {
		return "x=" + x + ", y=" + y;
	}

}
