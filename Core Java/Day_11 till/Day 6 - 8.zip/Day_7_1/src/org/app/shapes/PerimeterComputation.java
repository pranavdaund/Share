package org.app.shapes;

public interface PerimeterComputation {

	double calPerimeter();
}
