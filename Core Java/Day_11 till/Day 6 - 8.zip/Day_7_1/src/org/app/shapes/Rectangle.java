package org.app.shapes;

public class Rectangle extends BoundedShape {

	private double width, height;

	public Rectangle(int x, int y, double width, double height) {
		super(x, y);
		this.width = width;
		this.height = height;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Rectangle: " + super.toString() + ", width: " + width + ", heigth: " + height;
	}

	@Override
	public double calArea() {
		// TODO Auto-generated method stub
		return width * height;
	}

	@Override
	public double calPerimeter() {
		// TODO Auto-generated method stub
		return 2 * (width + height);
	}

}
