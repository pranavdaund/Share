package org.app.shapes;

public class Circle extends BoundedShape {

	private double radius;

	public Circle(int x, int y, double radius) {
		// TODO Auto-generated constructor stub
		super(x, y);
		this.radius = radius;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Circle: " + super.toString() + ", radius" + radius;
	}

	@Override
	public double calArea() {
		// TODO Auto-generated method stub
		return PI * (radius * radius);
	}

	@Override
	public double calPerimeter() {
		// TODO Auto-generated method stub
		return 2 * PI * radius;
	}

}
