package com.app.vehicle;

import java.util.Scanner;

public class VehicleMain {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the 1st Vehicle : regNo, color, price");
		Vehicle v1 = new Vehicle(sc.nextInt(), sc.next(), sc.nextDouble());
		System.out.println("Enter the 2nd Vehicle : regNo, color, price");
		Vehicle v2 = new Vehicle(sc.nextInt(), sc.next(), sc.nextDouble());
//
//		if (v1.getRegNo() == v2.getRegNo()) {
//			System.out.println("SAME");
//		} else {
//			System.out.println("Different");
//		}

//		v1 = v2;
		System.out.println(v1.equals(v2));

		System.out.println(v1.hashCode() + " " + v2.hashCode());
		System.out.println(v1 == v2);
		sc.close();

	}

}
