package com.app.vehicle;

public class Vehicle {
	private int regNo;
	private String color;
	private double price;

	public Vehicle(int regNo, String color, double price) {
		// TODO Auto-generated constructor stub
		this.regNo = regNo;
		this.color = color;
		this.price = price;
	}

	@Override
	public String toString() {
		return "Vehicle regNo=" + regNo + ", color=" + color + ", price=" + price;
	}

	public int getRegNo() {
		return regNo;
	}

	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		System.out.println("in vehical equal");
//		return super.equals(obj);
		return this.regNo == ((Vehicle) obj).regNo;
	}

}
