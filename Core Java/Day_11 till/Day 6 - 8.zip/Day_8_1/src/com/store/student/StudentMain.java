package com.store.student;

public class StudentMain {

	public static void main(String[] args) {
		Student s1 = new Student(101, "Pranav", "Daund", "Java", 8.07);
		Student s2 = new Student(101, "Om", "Patil", "Java", 8.5);
		System.out.println(s1.equals(s2));
	}

}
