package com.store.student;

public class Student {
	private int rollno;
	private String subject;
	private String firstName;
	private String lastName;
	private double gpa;

	public Student(int rollno, String firstName, String lastName, String subject, double gpa) {

		this.rollno = rollno;
		this.subject = subject;
		this.firstName = firstName;
		this.lastName = lastName;
		this.gpa = gpa;
	}

	@Override
	public boolean equals(Object o) {
		System.out.println("in student equal Method");
		if (o instanceof Student) {
			Student s = (Student) o;
			return ((this.rollno == s.rollno) && (this.subject.equals(s.subject)));
		}
		return false;
	}

}
