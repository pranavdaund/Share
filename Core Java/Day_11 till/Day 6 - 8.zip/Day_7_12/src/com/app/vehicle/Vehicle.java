package com.app.vehicle;

public class Vehicle {
	private int regNo;
	private String color;
	private double price;

	public Vehicle(int regNo, String color, double price) {
		// TODO Auto-generated constructor stub
		this.regNo = regNo;
		this.color = color;
		this.price = price;
	}

	@Override
	public String toString() {
		return "Vehicle regNo=" + regNo + ", color=" + color + ", price=" + price;
	}

	public int getRegNo() {
		return regNo;
	}

	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		System.out.println("in Vehicle equals Methods");
		if (obj instanceof Vehicle) {
			return this.regNo == ((Vehicle) obj).regNo;
		}
		return false;
	}

}
