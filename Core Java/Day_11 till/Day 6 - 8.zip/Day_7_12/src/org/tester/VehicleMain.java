package org.tester;

import java.util.Scanner;

import com.app.vehicle.Vehicle;

public class VehicleMain {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the 1st Vehicle : regNo, color, price");
		Vehicle v1 = new Vehicle(sc.nextInt(), sc.next(), sc.nextDouble());
		System.out.println("Enter the 2nd Vehicle : regNo, color, price");
		Vehicle v2 = new Vehicle(sc.nextInt(), sc.next(), sc.nextDouble());

		System.out.println(v1.equals(v2));
		System.out.println(v1.equals(sc));

//		
		sc.close();

	}

}
