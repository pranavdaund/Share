package org.pranav;

public class TestException4 {

	public static void main(String[] args) {
		String s = "123abc";
		System.out.println(Double.parseDouble(s)); // abort the code
		System.out.println("main");

	}

}
