package org.pranav;

public class TestFinally1 {

	public static void main(String[] args) {

		System.out.println("1");
		try {
			testme();
			System.out.println("back in main");
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("in main catch all" + e);
		} finally {
			System.out.println("in main finally");
		}
		System.out.println("main over");

	}

	public static void testme() throws InterruptedException {
		try {
			System.out.println("in method try");
			String[] ss = { "aa", "bb" };
			Thread.sleep(1000);
			System.out.println(ss[0]);
			boolean flag = false;
			if (flag) {
				return;
			}
			System.out.println("end of try");

		} finally {
			System.out.println("in method finally");
		}
		System.out.println("Method end");
	}

}
