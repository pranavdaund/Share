package org.pranav;

public class TestException2 {

	public static void main(String[] args) {
		int a = 100;
		int b = 10;
		try {
			System.out.println("Result is" + (a / b)); // run line
			System.out.println("End of try"); // run line
		} catch (ArithmeticException e) {
			// TODO: handle exception
			System.out.println("Exception Occurred");
		}
		System.out.println("main is Continue"); // run line
	}

}
