package org.pranav;

public class TestFinally5 {

	public static void main(String[] args) {

		System.out.println("1"); // execute line
		try {
			testme();
			System.out.println("back in main"); // not execute
		} catch (Exception e) {

			System.out.println("in main catch all " + e); // execute line
		} finally {
			System.out.println("in main finally");// execute line
		}
		System.out.println("main over");// execute line

	}

	public static void testme() throws InterruptedException {
		try {
			System.out.println("in method try"); // execute line
			String[] ss = { "aa", "bb" };
			Thread.sleep(1000);
			System.out.println(ss[2]); // Exception Occurred
			boolean flag = true;
			if (flag) {
				System.exit(0);// return function and finally block not execute because the code is
								// System.exit(0)
			}
			System.out.println("end of try"); // not execute

		} finally {
			System.out.println("in method finally"); // execute line
		}
		System.out.println("Method end"); // not execute
	}

}
