package org.pranav;

import java.util.Scanner;

public class TestTryWithResouce {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter your Complete Name");
			System.out.println("Hello " + sc.nextLine());
			System.out.println("Enter the Number");
			System.out.println("You entered: " + sc.nextInt());
			System.out.println("end of try");
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
		System.out.println("main is over");

	}

}
