package org.pranav;

public class TestException5 {

	public static void main(String[] args) {

	}

}
