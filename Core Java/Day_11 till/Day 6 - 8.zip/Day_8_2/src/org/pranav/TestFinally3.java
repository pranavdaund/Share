package org.pranav;

public class TestFinally3 {

	public static void main(String[] args) {

		System.out.println("1"); // execute line
		try {
			testme(); // execute line
			System.out.println("back in main"); // execute line
		} catch (Exception e) {

			System.out.println("in main catch all " + e);
		} finally {
			System.out.println("in main finally");// always run //execute line
		}
		System.out.println("main over");// execute line

	}

	public static void testme() throws InterruptedException {
		try {
			System.out.println("in method try"); // execute line
			String[] ss = { "aa", "bb" }; // execute line
			Thread.sleep(1000); // execute line
			System.out.println(ss[1]); // execute line
			boolean flag = true;
			if (flag) {
				return; // return function
			}
			System.out.println("end of try"); // not execute

		} finally {
			System.out.println("in method finally"); // always run //execute line
		}
		System.out.println("Method end"); // not run
	}

}
