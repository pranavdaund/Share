package org.pranav;

public class TestException3 {

	public static void main(String[] args) {
		String s = "123.45";
		System.out.println(Double.parseDouble(s));
		System.out.println("main");
	}

}
