package org.pranav;

public class TestException6 {

	public static void main(String[] args) {

		System.out.println("Before");
		// Thread.sleep(5000); // checked exception
		System.out.println("After");

	}

}
