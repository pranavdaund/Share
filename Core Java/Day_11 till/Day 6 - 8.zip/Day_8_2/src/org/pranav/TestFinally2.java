package org.pranav;

public class TestFinally2 {

	public static void main(String[] args) {

		System.out.println("1"); // execute line
		try {
			testme();
			System.out.println("back in main");
		} catch (Exception e) { // handle exception
			// TODO: handle exception
			System.out.println("in main catch all " + e); // always run //execute line
		} finally {
			System.out.println("in main finally");// execute line
		}
		System.out.println("main over");// execute line

	}

	public static void testme() throws InterruptedException {
		try {
			System.out.println("in method try"); // execute line
			String[] ss = { "aa", "bb" }; // execute line
			Thread.sleep(1000); // execute line
			System.out.println(ss[10]); // exception occurred
			boolean flag = false;
			if (flag) {
				return;
			}
			System.out.println("end of try"); // not execute line because code is aborted

		} finally {
			System.out.println("in method finally"); // always run //execute line
		}
		System.out.println("Method end"); // not handle exception
	}

}
