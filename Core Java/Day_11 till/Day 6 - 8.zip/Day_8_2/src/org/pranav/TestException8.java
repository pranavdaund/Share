package org.pranav;

public class TestException8 {

	public static void main(String[] args) {
		try {
			System.out.println("in main");
			int c = 100 / 10;
			System.out.println("result " + c);
			String s = "1234";
			System.out.println("parsed int value" + Integer.parseInt(s));
			s = "hello";
			System.out.println("Char at 0th index" + s.charAt(0));
			int[] data = { 1, 2, 3, 4, 5, 6 };
			System.out.println("Array Data:" + data[15]);
			System.out.println("End of try");
		} catch (ArithmeticException e) {
			System.out.println(e.getMessage());
		} catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
			// TODO: handle exception
			System.out.println(e);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

	}

}
