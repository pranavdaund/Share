package org.pranav;

public class TestException7 {

	public static void main(String[] args) {

		System.out.println("Before");
		try {
			Thread.sleep(5000); // checked exception
		} catch (InterruptedException e) {
			// TODO: handle exception
			System.out.println("error occurred");
		}
		System.out.println("After");

	}

}
