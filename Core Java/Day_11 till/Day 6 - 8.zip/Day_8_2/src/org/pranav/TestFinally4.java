package org.pranav;

public class TestFinally4 {

	public static void main(String[] args) {

		System.out.println("1"); // execute line
		try {
			testme(); // execute line exit the code // end of code (exit)
			System.out.println("back in main"); // not execute
		} catch (Exception e) {

			System.out.println("in main catch all " + e); // not execute
		} finally {
			System.out.println("in main finally");// not execute
		}
		System.out.println("main over");// not execute

	}

	public static void testme() throws InterruptedException {
		try {
			System.out.println("in method try"); // execute line
			String[] ss = { "aa", "bb" }; // execute line
			Thread.sleep(1000); // execute line
			System.out.println(ss[1]); // execute line
			boolean flag = true;
			if (flag) {
				System.exit(0);// return function and finally block not execute because the code is
								// System.exit(0)
			}
			System.out.println("end of try"); // not execute

		} finally {
			System.out.println("in method finally"); // not execute
		}
		System.out.println("Method end"); // not run
	}

}
