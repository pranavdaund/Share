package org.pranav;

public class TestException0 {

	public static void main(String[] args) {
		int a = 100;
		int b = 0;

		System.out.println("Result is" + (a / b)); // abort the code

		System.out.println("main is Continue");
	}

}
