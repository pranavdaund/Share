package org.pranav;

public class TestException1 {

	public static void main(String[] args) {
		int a = 100;
		int b = 0;
		try {
			System.out.println("Result is" + (a / b)); // throw exception
			System.out.println("End of try");
		} catch (ArithmeticException e) {
			// TODO: handle exception
			System.out.println("Exception Occurred"); // run line
		}
		System.out.println("main is Continue"); // run line
	}

}
