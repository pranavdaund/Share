package org.tester;


import org.pranav.ConsolePrinter;

public class Tester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ConsolePrinter printer = new ConsolePrinter();
		printer.print("Welcome");
//		System.out.println(printer.TEST_DATA);

	}

}
