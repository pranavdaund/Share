package org.tester;

import org.pranav.ConsolePrinter;
import org.pranav.Printable;

public class Tester3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ConsolePrinter printer = new ConsolePrinter();// direct refer
		printer.print("Welcome");

		Printable reference;

		// can not create interface object
//		reference = new Printable(); //javac error

		reference = printer;// upcasting
//		interface variable can it directly refer to any of its implemented class variable
		reference.print("new Message");
		reference = new ConsolePrinter();
		reference.print("new null value");

	}

}
