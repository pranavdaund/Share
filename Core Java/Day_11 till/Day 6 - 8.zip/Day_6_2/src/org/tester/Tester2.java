package org.tester;

import static org.pranav.Printable.TEST_DATA;

import org.pranav.ConsolePrinter;

public class Tester2 {

	public static void main(String[] args) {

		ConsolePrinter printer = new ConsolePrinter();
		printer.print("Welcome");
//		System.out.println(Printable.TEST_DATA);
		System.out.println("Interface :" + TEST_DATA);

	}

}
