package org.pranav2;

public class NetworkPrinter implements Printable {

	@Override
	public void print(String mesg) {
		// TODO Auto-generated method stub
		System.out.println("Sending " + mesg + " in the Network Printer");

	}

	public void encrytData(String mesg) {
		System.out.println("Encrypting the mesg: " + mesg);
	}

}
