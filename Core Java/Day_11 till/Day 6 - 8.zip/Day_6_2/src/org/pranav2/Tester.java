package org.pranav2;

public class Tester {
	public static void main(String[] args) {

		Printable printer;
		printer = new ConsolePrinter();
		printer.print("1st Mesg");
		printer = new FilePrinter();
		printer.print("1st Mesg");
		printer = new NetworkPrinter();
		printer.print("1st Mesg");

	}

}
