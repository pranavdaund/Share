package org.pranav2;

public class Tester3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Printable reference = new FilePrinter();
		reference.print("Input the File Class");

		Printable reference2 = new NetworkPrinter();
		reference2.print("the Message");
	}

}
