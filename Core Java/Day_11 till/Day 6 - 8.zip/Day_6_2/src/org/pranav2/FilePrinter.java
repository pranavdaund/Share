package org.pranav2;

public class FilePrinter implements Printable {

	@Override
	public void print(String mesg) {
		// TODO Auto-generated method stub
		System.out.println("Storing " + mesg + " in the file ");

	}

}
