package org.pranav2;

public interface Printable {
	
//	java adds : public static final
	double TEST_DATA = 123.45;
	
	void print(String mesg);
//	/Method specification alone -> This implements method  specification
	

}
