package org.pranav2;

public class ConsolePrinter implements Printable {

//	Must implements, inherited abstract functionality
	@Override
	public void print(String mesg) {
		System.out.println("Printing " + mesg+" on the Console");
		System.out.println(TEST_DATA);
	}
	
}
