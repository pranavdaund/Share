package org.pranav2;

public class Tester2 {

	public static void main(String[] args) {
		Printable[] printable = { new FilePrinter(), new ConsolePrinter(), new NetworkPrinter() };
		for (Printable p : printable) {
			p.print("Some mesg!!!");
			if (p instanceof NetworkPrinter) {
				((NetworkPrinter) p).encrytData("New mesg"); // This method encrytData is undefind for the printable
			} else {
				System.out.println("Can't encrypt data!!!");
			}
		}
	}

}
